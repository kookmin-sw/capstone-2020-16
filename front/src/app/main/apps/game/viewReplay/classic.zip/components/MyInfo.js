// import React from "react";

// const MyInfo = ({ next, previous, placement }) => {
//     return (
//         <div>
//             <h1>{placement}</h1>
//         </div>
//     )
// }

// export default MyInfo;